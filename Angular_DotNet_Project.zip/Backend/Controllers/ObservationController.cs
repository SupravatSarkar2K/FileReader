
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.IO;
using YourProject.Models;

namespace YourProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ObservationController : ControllerBase
    {
        private readonly string filePath = "data.json";

        [HttpGet]
        public IActionResult Get()
        {
            var json = System.IO.File.ReadAllText(filePath);
            return Ok(JsonConvert.DeserializeObject<Observation>(json));
        }

        [HttpPost]
        public IActionResult Save([FromBody] Observation observation)
        {
            var json = JsonConvert.SerializeObject(observation, Formatting.Indented);
            System.IO.File.WriteAllText(filePath, json);
            return Ok(new { message = "Saved successfully" });
        }
    }
}
