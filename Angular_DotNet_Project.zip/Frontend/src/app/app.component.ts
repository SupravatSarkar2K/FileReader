
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  observation: any;
  selectedData: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('http://localhost:5000/api/observation').subscribe(data => this.observation = data);
  }

  onSelect(event: any) {
    this.selectedData = event.option.value;
  }

  save() {
    this.http.post('http://localhost:5000/api/observation', this.observation).subscribe(alert);
  }
}
